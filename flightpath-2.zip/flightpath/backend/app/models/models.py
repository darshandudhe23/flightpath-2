from datetime import datetime, timezone
from app.database import db

def _now(): return datetime.now(timezone.utc)

class Airport(db.Model):
    __tablename__ = "airports"
    id = db.Column(db.Integer, primary_key=True)
    iata = db.Column(db.String(3), unique=True, nullable=False, index=True)
    name = db.Column(db.String(120), nullable=False)
    city = db.Column(db.String(80), nullable=False)
    country = db.Column(db.String(80), nullable=False)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    def to_dict(self):
        return dict(id=self.id, iata=self.iata, name=self.name, city=self.city, country=self.country,
                    latitude=self.latitude, longitude=self.longitude)

class Airline(db.Model):
    __tablename__ = "airlines"
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(3), unique=True, nullable=False)
    name = db.Column(db.String(80), nullable=False)

class Flight(db.Model):
    """A directed flight connection (graph edge). SIMULATED sample data."""
    __tablename__ = "flights"
    id = db.Column(db.Integer, primary_key=True)
    flight_number = db.Column(db.String(10), nullable=False)
    airline_id = db.Column(db.Integer, db.ForeignKey("airlines.id"), nullable=False)
    origin_id = db.Column(db.Integer, db.ForeignKey("airports.id"), nullable=False, index=True)
    destination_id = db.Column(db.Integer, db.ForeignKey("airports.id"), nullable=False, index=True)
    distance_km = db.Column(db.Float, nullable=False)
    duration_min = db.Column(db.Integer, nullable=False)
    price_inr = db.Column(db.Float, nullable=False)
    airline = db.relationship("Airline")
    origin = db.relationship("Airport", foreign_keys=[origin_id])
    destination = db.relationship("Airport", foreign_keys=[destination_id])

class SavedRoute(db.Model):
    __tablename__ = "saved_routes"
    id = db.Column(db.Integer, primary_key=True)
    path = db.Column(db.String(200), nullable=False)
    criterion = db.Column(db.String(20), nullable=False, default="price")
    label = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=_now)
    def to_dict(self):
        return dict(id=self.id, path=self.path.split(","), criterion=self.criterion, label=self.label,
                    created_at=self.created_at.isoformat())

class SearchHistory(db.Model):
    __tablename__ = "search_history"
    id = db.Column(db.Integer, primary_key=True)
    origin = db.Column(db.String(3), nullable=False)
    destination = db.Column(db.String(3), nullable=False)
    travel_date = db.Column(db.String(10))
    passengers = db.Column(db.Integer, default=1)
    travel_class = db.Column(db.String(20), default="economy")
    created_at = db.Column(db.DateTime, default=_now)
    def to_dict(self):
        return dict(id=self.id, origin=self.origin, destination=self.destination, date=self.travel_date,
                    passengers=self.passengers, travel_class=self.travel_class, created_at=self.created_at.isoformat())

class FavoriteAirport(db.Model):
    __tablename__ = "favorite_airports"
    id = db.Column(db.Integer, primary_key=True)
    airport_id = db.Column(db.Integer, db.ForeignKey("airports.id"), unique=True, nullable=False)
    airport = db.relationship("Airport")
