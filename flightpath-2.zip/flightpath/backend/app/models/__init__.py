from .models import Airport, Airline, Flight, SavedRoute, SearchHistory, FavoriteAirport
