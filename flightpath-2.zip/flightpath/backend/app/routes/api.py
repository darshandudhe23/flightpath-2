from flask import Blueprint, jsonify, request
from sqlalchemy import or_
from app.database import db
from app.models import Airport, SavedRoute, SearchHistory, FavoriteAirport
from app.services import route_service as rs
from app.utils.errors import ApiError

bp = Blueprint("api", __name__, url_prefix="/api")

def body():
    d = request.get_json(silent=True)
    if not isinstance(d, dict): raise ApiError("Request body must be a JSON object.")
    return d

def int_in(v, name, lo, hi):
    if isinstance(v, bool) or not isinstance(v, int) or not lo <= v <= hi: raise ApiError(f"{name} must be an integer between {lo} and {hi}")
    return v

def ctx(d):
    tc = d.get("travel_class", "economy")
    if tc not in rs.CLASS_MULT: raise ApiError(f"travel_class must be one of {list(rs.CLASS_MULT)}")
    return dict(date=d.get("date"), passengers=int_in(d.get("passengers", 1), "passengers", 1, 9), travel_class=tc)

@bp.get("/health")
def health(): return jsonify(status="ok", data_notice=rs.DATA_NOTICE)

@bp.get("/airports")
def airports(): return jsonify([a.to_dict() for a in Airport.query.order_by(Airport.city)])

@bp.get("/airports/search")
def airport_search():
    q = (request.args.get("q") or "").strip()
    if not q: return jsonify([])
    like = f"%{q}%"
    rows = Airport.query.filter(or_(Airport.iata.ilike(like), Airport.city.ilike(like), Airport.name.ilike(like), Airport.country.ilike(like))).limit(30).all()
    rows.sort(key=lambda a: (a.iata.lower() != q.lower(), not a.city.lower().startswith(q.lower()), a.city))
    return jsonify([a.to_dict() for a in rows[:10]])

@bp.post("/routes/optimize")
def optimize():
    d = body(); r = rs.optimize(d.get("origin"), d.get("destination"), d.get("optimize_by"), **ctx(d))
    if r is None: raise ApiError("No route found between these airports.", 404)
    return jsonify(r)

def _max_stops(d):
    ms = d.get("max_stops")
    return None if ms is None else int_in(ms, "max_stops", 0, 6)

@bp.post("/routes/alternatives")
def alternatives():
    d = body()
    routes = rs.alternatives(d.get("origin"), d.get("destination"), d.get("optimize_by"), d.get("k", 5), _max_stops(d), **ctx(d))
    return jsonify(routes=routes, count=len(routes))

@bp.post("/flights/search")
def flight_search():
    d = body(); c = ctx(d)
    routes = rs.alternatives(d.get("origin"), d.get("destination"), d.get("optimize_by"), d.get("k", 6), _max_stops(d), **c)
    o, de = rs.validate_pair(d.get("origin"), d.get("destination"))
    db.session.add(SearchHistory(origin=o, destination=de, travel_date=c["date"], passengers=c["passengers"], travel_class=c["travel_class"]))
    db.session.commit()
    return jsonify(routes=routes, count=len(routes), origin=o, destination=de, data_notice=rs.DATA_NOTICE)

@bp.get("/routes/details")
def details():
    path = [c for c in (request.args.get("path") or "").upper().split(",") if c]
    if len(path) < 2: raise ApiError("path must list at least two airport codes, e.g. ?path=DEL,DXB,JFK")
    return jsonify(rs.route_details(path, request.args.get("optimize_by")))

@bp.post("/routes/compare")
def compare():
    d = body(); return jsonify(rs.compare(d.get("routes"), rs.validate_criterion(d.get("optimize_by")), **ctx(d)))

@bp.post("/saved-routes")
def save_route():
    d = body(); path = d.get("path")
    if not isinstance(path, list) or len(path) < 2: raise ApiError("path must be a list of at least two airport codes.")
    path = [str(c).upper() for c in path]; rs.route_details(path)
    p = ",".join(path)
    if SavedRoute.query.filter_by(path=p).first(): raise ApiError("Route already saved.", 409)
    s = SavedRoute(path=p, criterion=rs.validate_criterion(d.get("optimize_by")), label=(d.get("label") or "")[:120] or None)
    db.session.add(s); db.session.commit()
    return jsonify(s.to_dict()), 201

@bp.get("/saved-routes")
def list_saved(): return jsonify([s.to_dict() for s in SavedRoute.query.order_by(SavedRoute.created_at.desc())])

@bp.delete("/saved-routes/<int:rid>")
def delete_saved(rid):
    s = db.session.get(SavedRoute, rid)
    if not s: raise ApiError("Saved route not found.", 404)
    db.session.delete(s); db.session.commit(); return "", 204

@bp.get("/search-history")
def history(): return jsonify([h.to_dict() for h in SearchHistory.query.order_by(SearchHistory.id.desc()).limit(10)])

@bp.delete("/search-history")
def clear_history():
    SearchHistory.query.delete(); db.session.commit(); return "", 204

@bp.get("/favorites")
def favorites(): return jsonify([f.airport.to_dict() for f in FavoriteAirport.query.all()])

@bp.post("/favorites")
def add_fav():
    code = str(body().get("iata") or "").upper(); a = Airport.query.filter_by(iata=code).first()
    if not a: raise ApiError("Unknown airport.", 404)
    if not FavoriteAirport.query.filter_by(airport_id=a.id).first():
        db.session.add(FavoriteAirport(airport_id=a.id)); db.session.commit()
    return jsonify(a.to_dict()), 201

@bp.delete("/favorites/<code>")
def del_fav(code):
    a = Airport.query.filter_by(iata=code.upper()).first()
    if a: FavoriteAirport.query.filter_by(airport_id=a.id).delete(); db.session.commit()
    return "", 204
