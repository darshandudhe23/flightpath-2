import csv, os
from app.database import db
from app.models import Airport, Airline, Flight
DATA = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "datasets"))

def _rows(name):
    with open(os.path.join(DATA, name), encoding="utf-8", newline="") as f: yield from csv.DictReader(f)

def seed(reset=False):
    """Create tables and load datasets/*.csv (simulated sample data). No-op if already seeded."""
    if reset: db.drop_all()
    db.create_all()
    if Airport.query.count(): return False
    air, lines = {}, {}
    for r in _rows("airports.csv"):
        a = Airport(iata=r["iata"], name=r["name"], city=r["city"], country=r["country"], latitude=float(r["latitude"]), longitude=float(r["longitude"]))
        db.session.add(a); air[a.iata] = a
    for r in _rows("airlines.csv"):
        l = Airline(code=r["code"], name=r["name"]); db.session.add(l); lines[l.code] = l
    db.session.flush()
    for r in _rows("routes.csv"):
        db.session.add(Flight(flight_number=r["flight_number"], airline_id=lines[r["airline_code"]].id, origin_id=air[r["origin"]].id,
            destination_id=air[r["destination"]].id, distance_km=float(r["distance_km"]), duration_min=int(r["duration_min"]), price_inr=float(r["price_inr"])))
    db.session.commit(); return True
