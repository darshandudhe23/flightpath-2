import os
from flask import Flask
from flask_cors import CORS
from app.database import db
from app.utils.errors import register_error_handlers

def create_app(config=None):
    app = Flask(__name__)
    base = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    app.config.update(SQLALCHEMY_DATABASE_URI="sqlite:///" + os.path.join(base, "flightpath.db"), SQLALCHEMY_TRACK_MODIFICATIONS=False)
    if config: app.config.update(config)
    CORS(app)
    db.init_app(app)
    from app.routes.api import bp
    app.register_blueprint(bp)
    register_error_handlers(app)
    with app.app_context():
        from app.database.seed import seed
        seed()
    return app
