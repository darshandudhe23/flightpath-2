from datetime import datetime, timedelta
from app.algorithms.graph import FlightGraph, CRITERIA, dijkstra, yen_k_shortest
from app.models import Airport, Flight
from app.utils.errors import ApiError

LAYOVER_MIN = 90
CLASS_MULT = {"economy": 1.0, "premium": 1.5, "business": 2.8, "first": 4.0}
DATA_NOTICE = "Simulated / estimated sample data. Not real-time schedules, availability or ticket prices."

def build_graph():
    g = FlightGraph()
    for a in Airport.query.all(): g.add_airport(a.iata)
    for f in Flight.query.all():
        g.add_flight(f.origin.iata, f.destination.iata, dict(
            flight_number=f.flight_number, airline=f.airline.name, airline_code=f.airline.code,
            distance_km=f.distance_km, duration_min=f.duration_min, price=f.price_inr))
    return g

def validate_pair(origin, destination):
    origin, destination = (origin or "").upper().strip(), (destination or "").upper().strip()
    if not origin or not destination: raise ApiError("Origin and destination are required.")
    if origin == destination: raise ApiError("Origin and destination must be different airports.")
    found = {a.iata for a in Airport.query.filter(Airport.iata.in_([origin, destination]))}
    for code in (origin, destination):
        if code not in found: raise ApiError(f"Unknown airport code: {code}", 404)
    return origin, destination

def validate_criterion(c):
    c = c or "price"
    if c not in CRITERIA: raise ApiError(f"optimize_by must be one of {list(CRITERIA)}")
    return c

def describe_route(graph, path, criterion, date=None, passengers=1, travel_class="economy"):
    """Turns a list of airport codes into a full route description (legs, totals, times)."""
    airports = {a.iata: a for a in Airport.query.filter(Airport.iata.in_(path))}
    mult = CLASS_MULT.get(travel_class, 1.0)
    try: t = datetime.strptime(date, "%Y-%m-%d").replace(hour=8) if date else datetime(2000, 1, 1, 8)
    except ValueError: raise ApiError("date must be YYYY-MM-DD")
    start, legs, dist, dur, price = t, [], 0.0, 0, 0.0
    for i, (u, v) in enumerate(zip(path, path[1:])):
        f = graph.best_flight(u, v, criterion)
        arr = t + timedelta(minutes=f["duration_min"])
        legs.append({"from": u, "to": v, "airline": f["airline"], "airline_code": f["airline_code"],
                     "flight_number": f["flight_number"], "distance_km": f["distance_km"], "duration_min": f["duration_min"],
                     "price": round(f["price"] * mult), "departure": t.isoformat(), "arrival": arr.isoformat()})
        dist += f["distance_km"]; dur += f["duration_min"]; price += f["price"] * mult
        t = arr + timedelta(minutes=LAYOVER_MIN)
        if i < len(path) - 2: dur += LAYOVER_MIN
    return dict(
        path=path, stops=len(path) - 2, route_type="Direct" if len(path) == 2 else "Connecting",
        layovers=[dict(iata=c, city=airports[c].city) for c in path[1:-1]],
        airlines=sorted({l["airline"] for l in legs}), legs=legs,
        total_distance_km=round(dist), total_duration_min=dur, total_price=round(price * passengers),
        price_per_passenger=round(price), departure=start.isoformat(), arrival=legs[-1]["arrival"],
        airports=[airports[c].to_dict() for c in path], data_notice=DATA_NOTICE)

def optimize(origin, destination, criterion, **kw):
    origin, destination = validate_pair(origin, destination)
    criterion = validate_criterion(criterion)
    g = build_graph()
    res = dijkstra(g, origin, destination, criterion)
    if res is None: return None
    r = describe_route(g, res[1], criterion, **kw); r["optimized_for"] = criterion; r["cost"] = res[0]
    return r

def alternatives(origin, destination, criterion, k=5, max_stops=None, **kw):
    origin, destination = validate_pair(origin, destination)
    criterion = validate_criterion(criterion)
    if isinstance(k, bool) or not isinstance(k, int) or not 1 <= k <= 10: raise ApiError("k must be an integer between 1 and 10")
    g = build_graph()
    found = yen_k_shortest(g, origin, destination, 10 if max_stops is not None else k, criterion)  # over-fetch for the stops filter
    out = []
    for cost, path in found:
        if max_stops is not None and len(path) - 2 > max_stops: continue
        r = describe_route(g, path, criterion, **kw); r["optimized_for"] = criterion; r["cost"] = cost
        out.append(r)
    out = out[:k]
    for i, r in enumerate(out): r["is_optimal"] = i == 0
    return out

def route_details(path, criterion=None):
    g = build_graph()
    if any(not g.has(c) for c in path) or any(b not in g.adj[a] for a, b in zip(path, path[1:])): raise ApiError("Invalid route.", 404)
    return describe_route(g, path, validate_criterion(criterion))

def compare(paths, criterion="price", **kw):
    if not isinstance(paths, list) or not 2 <= len(paths) <= 4: raise ApiError("Provide 2 to 4 routes to compare.")
    g = build_graph(); routes = []
    for p in paths:
        if not isinstance(p, list): raise ApiError("Each route must be a list of airport codes.")
        p = [str(c).upper() for c in p]
        if len(p) < 2 or any(not g.has(c) for c in p) or any(b not in g.adj[a] for a, b in zip(p, p[1:])):
            raise ApiError(f"Invalid route: {'-'.join(p)}")
        routes.append(describe_route(g, p, criterion, **kw))
    pick = lambda f: min(range(len(routes)), key=lambda i: routes[i][f])
    best = {"price": pick("total_price"), "duration_min": pick("total_duration_min"),
            "distance_km": pick("total_distance_km"), "stops": pick("stops")}
    return dict(routes=routes, best=best, recommended_index=best[criterion], optimized_for=criterion, data_notice=DATA_NOTICE)
