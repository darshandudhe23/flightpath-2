from flask import jsonify
class ApiError(Exception):
    def __init__(self, message, status=400): super().__init__(message); self.message, self.status = message, status
def register_error_handlers(app):
    @app.errorhandler(ApiError)
    def _api(e): return jsonify(error=e.message), e.status
    @app.errorhandler(404)
    def _404(e): return jsonify(error="Not found"), 404
    @app.errorhandler(405)
    def _405(e): return jsonify(error="Method not allowed"), 405
    @app.errorhandler(Exception)
    def _500(e):
        app.logger.exception(e); return jsonify(error="Internal server error"), 500
