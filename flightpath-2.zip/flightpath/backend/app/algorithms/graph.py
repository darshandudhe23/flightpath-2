"""Weighted directed graph (adjacency list) + Dijkstra (min-heap) + Yen's K shortest paths.

Vertices are IATA codes. Between two airports there may be several parallel flights (different airlines);
the graph keeps all of them and, per criterion, uses the best parallel edge as the edge weight.
Each criterion (distance_km, duration_min, price) is optimised separately - units are never mixed.
"""
import heapq
from itertools import count

CRITERIA = ("distance_km", "duration_min", "price")

class FlightGraph:
    def __init__(self):
        self.adj = {}   # u -> {v -> [flight dict, ...]}

    def add_airport(self, code):
        self.adj.setdefault(code, {})

    def add_flight(self, u, v, flight):
        self.add_airport(u); self.add_airport(v)
        self.adj[u].setdefault(v, []).append(flight)

    def has(self, code): return code in self.adj

    def best_flight(self, u, v, criterion):
        return min(self.adj[u][v], key=lambda f: f[criterion])

    def weight(self, u, v, criterion):
        return self.best_flight(u, v, criterion)[criterion]

    def path_cost(self, path, criterion):
        return sum(self.weight(a, b, criterion) for a, b in zip(path, path[1:]))


def dijkstra(graph, source, target, criterion="distance_km", banned_nodes=frozenset(), banned_edges=frozenset()):
    """Returns (cost, [airport codes]) or None if the target is unreachable."""
    if criterion not in CRITERIA: raise ValueError(f"Unknown criterion: {criterion}")
    if not graph.has(source) or not graph.has(target): return None
    if source in banned_nodes or target in banned_nodes: return None
    dist = {source: 0.0}
    prev = {}
    tie = count()                                  # tie-breaker so the heap never compares strings
    heap = [(0.0, next(tie), source)]
    done = set()
    while heap:
        d, _, u = heapq.heappop(heap)
        if u in done: continue
        done.add(u)
        if u == target: break
        for v in graph.adj[u]:
            if v in banned_nodes or v in done or (u, v) in banned_edges: continue
            nd = d + graph.weight(u, v, criterion)
            if nd < dist.get(v, float("inf")):
                dist[v] = nd; prev[v] = u
                heapq.heappush(heap, (nd, next(tie), v))
    if target not in done: return None
    path = [target]
    while path[-1] != source: path.append(prev[path[-1]])
    path.reverse()
    return dist[target], path


def yen_k_shortest(graph, source, target, k=3, criterion="distance_km"):
    """Yen's algorithm. Returns up to k loop-free, distinct paths [(cost, path), ...] in increasing cost."""
    first = dijkstra(graph, source, target, criterion)
    if first is None or source == target: return [first] if first else []
    A, B, seen = [first], [], {tuple(first[1])}
    for _ in range(1, k):
        last = A[-1][1]
        for i in range(len(last) - 1):
            spur, root = last[i], last[:i + 1]
            banned_edges = {(p[i], p[i + 1]) for _, p in A if len(p) > i + 1 and p[:i + 1] == root}
            res = dijkstra(graph, spur, target, criterion, set(root[:-1]), banned_edges)
            if res is None: continue
            cand = root[:-1] + res[1]
            if tuple(cand) in seen: continue
            seen.add(tuple(cand))
            heapq.heappush(B, (graph.path_cost(cand, criterion), cand))
        if not B: break
        A.append(heapq.heappop(B))
    return A
