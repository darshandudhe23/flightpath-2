import pytest
from app import create_app

@pytest.fixture(scope="module")
def client(tmp_path_factory):
    app = create_app({"SQLALCHEMY_DATABASE_URI": "sqlite:///" + str(tmp_path_factory.mktemp("db") / "t.db"), "TESTING": True})
    return app.test_client()

def post(c, url, **j): return c.post(url, json=j)

def test_airports(client):
    r = client.get("/api/airports"); assert r.status_code == 200 and len(r.json) >= 40

def test_search_autocomplete(client):
    r = client.get("/api/airports/search?q=del"); assert r.json[0]["iata"] == "DEL"
    assert client.get("/api/airports/search?q=").json == []

def test_optimize(client):
    r = post(client, "/api/routes/optimize", origin="NDC", destination="JFK", optimize_by="distance_km")
    assert r.status_code == 200 and r.json["path"][0] == "NDC" and r.json["path"][-1] == "JFK"
    assert r.json["total_distance_km"] > 0

def test_same_airport(client):
    assert post(client, "/api/routes/optimize", origin="DEL", destination="DEL").status_code == 400

def test_unknown_airport(client):
    assert post(client, "/api/routes/optimize", origin="DEL", destination="XXX").status_code == 404

def test_bad_criterion(client):
    assert post(client, "/api/routes/optimize", origin="DEL", destination="BOM", optimize_by="vibes").status_code == 400

def test_bad_body(client):
    assert client.post("/api/routes/optimize", data="nope").status_code == 400

def test_alternatives_distinct(client):
    r = post(client, "/api/routes/alternatives", origin="DEL", destination="JFK", optimize_by="price", k=5)
    paths = [tuple(x["path"]) for x in r.json["routes"]]
    assert r.status_code == 200 and len(paths) == len(set(paths)) > 1 and r.json["routes"][0]["is_optimal"]

def test_max_stops_filter(client):
    r = post(client, "/api/flights/search", origin="DEL", destination="JFK", optimize_by="price", max_stops=1, passengers=2, travel_class="business")
    assert r.status_code == 200 and all(x["stops"] <= 1 for x in r.json["routes"])

def test_bad_passengers(client):
    assert post(client, "/api/flights/search", origin="DEL", destination="BOM", passengers=0).status_code == 400

def test_compare_and_details(client):
    r = post(client, "/api/routes/compare", routes=[["DEL","DXB","JFK"],["DEL","LHR","JFK"]], optimize_by="duration_min")
    assert r.status_code == 200 and len(r.json["routes"]) == 2 and r.json["recommended_index"] in (0, 1)
    assert post(client, "/api/routes/compare", routes=[["DEL","BOM"]]).status_code == 400
    d = client.get("/api/routes/details?path=DEL,DXB,JFK"); assert d.status_code == 200 and d.json["stops"] == 1
    assert client.get("/api/routes/details?path=DEL,NDC").status_code == 404

def test_saved_routes_and_history(client):
    assert post(client, "/api/saved-routes", path=["DEL","DXB","JFK"]).status_code == 201
    assert post(client, "/api/saved-routes", path=["DEL","DXB","JFK"]).status_code == 409
    saved = client.get("/api/saved-routes").json; assert saved[0]["path"] == ["DEL","DXB","JFK"]
    assert client.delete(f"/api/saved-routes/{saved[0]['id']}").status_code == 204
    assert client.delete("/api/saved-routes/9999").status_code == 404
    assert len(client.get("/api/search-history").json) >= 1

def test_favorites(client):
    assert post(client, "/api/favorites", iata="SIN").status_code == 201
    assert client.get("/api/favorites").json[0]["iata"] == "SIN"
    assert client.delete("/api/favorites/SIN").status_code == 204 and client.get("/api/favorites").json == []
