import pytest
from app.algorithms.graph import FlightGraph, dijkstra, yen_k_shortest

def fl(d, t=None, p=None): return dict(distance_km=d, duration_min=t or d, price=p or d, airline="X", airline_code="X", flight_number="X1")

@pytest.fixture
def g():
    g = FlightGraph()
    for u, v, d in [("A","B",4),("A","C",2),("C","B",1),("B","D",5),("C","D",8),("D","E",3),("C","E",10)]:
        g.add_flight(u, v, fl(d))
    g.add_airport("Z")  # isolated
    return g

def test_dijkstra_shortest(g):
    cost, path = dijkstra(g, "A", "E", "distance_km")
    assert path == ["A","C","B","D","E"] and cost == 11

def test_unreachable(g): assert dijkstra(g, "A", "Z") is None
def test_unknown_node(g): assert dijkstra(g, "A", "Q") is None
def test_bad_criterion(g):
    with pytest.raises(ValueError): dijkstra(g, "A", "E", "nope")

def test_parallel_edges_use_cheapest():
    g = FlightGraph(); g.add_flight("A","B",fl(100, p=900)); g.add_flight("A","B",fl(120, p=300))
    assert dijkstra(g,"A","B","price")[0] == 300
    assert dijkstra(g,"A","B","distance_km")[0] == 100

def test_criteria_are_independent():
    g = FlightGraph()
    g.add_flight("A","B",fl(100,t=500,p=100)); g.add_flight("A","C",fl(300,t=50,p=900)); g.add_flight("C","B",fl(300,t=50,p=900)); g.add_flight("B","D",fl(1,1,1))
    assert dijkstra(g,"A","B","distance_km")[1] == ["A","B"]
    assert dijkstra(g,"A","B","duration_min")[1] == ["A","C","B"]

def test_yen_distinct_sorted_loop_free(g):
    res = yen_k_shortest(g, "A", "E", 5, "distance_km")
    paths = [tuple(p) for _, p in res]
    assert len(paths) == len(set(paths)) and len(paths) >= 3
    costs = [c for c, _ in res]; assert costs == sorted(costs)
    assert all(len(set(p)) == len(p) for p in paths)
    assert paths[0] == ("A","C","B","D","E")

def test_yen_fewer_than_k(g):
    assert len(yen_k_shortest(g, "D", "E", 10)) == 1
    assert yen_k_shortest(g, "A", "Z") == []
