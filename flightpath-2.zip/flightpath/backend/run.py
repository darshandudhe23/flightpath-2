"""Run the API:  python run.py        Reset + reseed DB:  python run.py --reset"""
import sys
from app import create_app
app = create_app()
if __name__ == "__main__":
    if "--reset" in sys.argv:
        from app.database import db
        from app.database.seed import seed
        with app.app_context(): seed(reset=True)
        print("Database reset and seeded.")
    app.run(debug=True, port=5000)
