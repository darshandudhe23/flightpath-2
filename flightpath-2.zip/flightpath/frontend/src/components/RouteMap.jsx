import { useEffect } from "react";
import { MapContainer, TileLayer, Polyline, CircleMarker, Tooltip, Popup, useMap } from "react-leaflet";
import { fmtDuration, fmtKm, fmtPrice } from "../services/format.js";

const DASHES = [null, "8 8", "2 8", "14 6 2 6", "4 4"];
const COLORS = ["#2563eb", "#64748b", "#0891b2", "#9333ea", "#ea580c"];

function Fit({ points }) {
  const map = useMap();
  useEffect(() => { if (points.length) map.fitBounds(points, { padding: [40, 40], maxZoom: 5 }); }, [points, map]);
  return null;
}

/** routes: route objects from the API; selected: index of highlighted route; onSelect(i) */
export default function RouteMap({ routes, selected = 0, onSelect, height = 420 }) {
  const sel = routes[selected];
  const points = routes.flatMap((r) => r.airports.map((a) => [a.latitude, a.longitude]));
  const airports = new Map(routes.flatMap((r) => r.airports.map((a) => [a.iata, a])));
  const ends = sel ? [sel.path[0], sel.path.at(-1)] : [];
  const order = routes.map((_, i) => i).sort((a, b) => (a === selected) - (b === selected));   // draw selected on top

  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200 shadow-sm" style={{ height }}>
      <MapContainer center={[25, 60]} zoom={3} minZoom={2} worldCopyJump className="h-full w-full" scrollWheelZoom>
        <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <Fit points={points} />
        {order.map((i) => {
          const r = routes[i], active = i === selected;
          return (
            <Polyline key={r.path.join("-")} positions={r.airports.map((a) => [a.latitude, a.longitude])}
              pathOptions={{ color: active ? "#2563eb" : COLORS[i % COLORS.length], weight: active ? 5 : 2.5, opacity: active ? 0.95 : 0.55, dashArray: active ? null : DASHES[i % DASHES.length] }}
              eventHandlers={{ click: () => onSelect?.(i) }}>
              <Popup>
                <div className="text-sm"><b>{r.path.join(" → ")}</b>{r.is_optimal && <span className="ml-1 text-blue-600">★ Optimal</span>}<br />
                  {fmtKm(r.total_distance_km)} · {fmtDuration(r.total_duration_min)} · {fmtPrice(r.total_price)}<br />
                  {r.stops === 0 ? "Direct" : `${r.stops} stop${r.stops > 1 ? "s" : ""}`}</div>
              </Popup>
            </Polyline>
          );
        })}
        {[...airports.values()].map((a) => {
          const isEnd = ends.includes(a.iata), onSel = sel?.path.includes(a.iata);
          return (
            <CircleMarker key={a.iata} center={[a.latitude, a.longitude]} radius={isEnd ? 9 : onSel ? 7 : 5}
              pathOptions={{ color: "#fff", weight: 2, fillOpacity: 1, fillColor: isEnd ? "#0b1f3a" : onSel ? "#2563eb" : "#94a3b8" }}>
              <Tooltip permanent direction="top" offset={[0, -6]}>{a.iata}</Tooltip>
              <Popup><div className="text-sm"><b>{a.name}</b> ({a.iata})<br />{a.city}, {a.country}<br />
                <span className="text-slate-500">{isEnd ? (a.iata === sel.path[0] ? "Origin" : "Destination") : onSel ? "Connecting airport" : "Alternative route"}</span></div></Popup>
            </CircleMarker>
          );
        })}
      </MapContainer>
    </div>
  );
}
