import { useEffect, useRef, useState } from "react";
import { MapPin } from "lucide-react";
import { api } from "../services/api.js";

export default function AirportInput({ label, value, onChange, exclude, placeholder }) {
  const [text, setText] = useState(value ? `${value.city} (${value.iata})` : "");
  const [options, setOptions] = useState([]);
  const [open, setOpen] = useState(false);
  const box = useRef(null);

  useEffect(() => { setText(value ? `${value.city} (${value.iata})` : ""); }, [value]);
  useEffect(() => {
    const close = (e) => box.current && !box.current.contains(e.target) && setOpen(false);
    document.addEventListener("mousedown", close); return () => document.removeEventListener("mousedown", close);
  }, []);
  useEffect(() => {
    if (!open || !text.trim() || (value && text === `${value.city} (${value.iata})`)) return;
    const t = setTimeout(() => api.searchAirports(text.trim()).then(setOptions).catch(() => setOptions([])), 180);
    return () => clearTimeout(t);
  }, [text, open, value]);

  const visible = options.filter((a) => a.iata !== exclude);
  return (
    <div ref={box} className="relative">
      <label className="label">{label}</label>
      <div className="relative">
        <MapPin size={16} className="absolute left-3 top-3.5 text-slate-400" />
        <input className="input pl-9" value={text} placeholder={placeholder} autoComplete="off"
          onFocus={() => setOpen(true)} onChange={(e) => { setText(e.target.value); setOpen(true); if (value) onChange(null); }} />
      </div>
      {open && text.trim() && (
        <ul className="absolute z-30 mt-1 max-h-64 w-full overflow-auto rounded-xl border border-slate-200 bg-white py-1 shadow-xl">
          {visible.length === 0 && <li className="px-3 py-2 text-sm text-slate-500">No matching airports</li>}
          {visible.map((a) => (
            <li key={a.iata}><button type="button" className="flex w-full items-center gap-3 px-3 py-2 text-left hover:bg-brand-50"
              onClick={() => { onChange(a); setOpen(false); }}>
              <span className="w-10 rounded bg-navy-900 py-0.5 text-center text-xs font-bold text-white">{a.iata}</span>
              <span className="min-w-0"><span className="block truncate text-sm font-medium">{a.city}, {a.country}</span><span className="block truncate text-xs text-slate-500">{a.name}</span></span>
            </button></li>
          ))}
        </ul>
      )}
    </div>
  );
}
