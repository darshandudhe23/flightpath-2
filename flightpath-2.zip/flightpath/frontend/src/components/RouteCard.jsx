import { useState } from "react";
import { Link } from "react-router-dom";
import { Bookmark, BookmarkCheck, ChevronDown, Star } from "lucide-react";
import AirlineLogo from "./AirlineLogo.jsx";
import { dayOffset, fmtDuration, fmtKm, fmtPrice, fmtTime } from "../services/format.js";

export default function RouteCard({ route: r, active, onSelect, compared, onToggleCompare, saved, onToggleSave, pax }) {
  const [open, setOpen] = useState(false);
  const off = dayOffset(r.departure, r.arrival);
  const first = r.legs[0], last = r.legs.at(-1);
  return (
    <article onClick={onSelect} className={`card cursor-pointer p-5 transition hover:-translate-y-0.5 hover:shadow-lg ${r.is_optimal ? "border-l-4 border-l-brand-500" : ""} ${active ? "ring-2 ring-brand-500" : ""}`}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-3">
          <div className="flex -space-x-2">{[...new Set(r.legs.map((l) => l.airline_code))].map((c) => <AirlineLogo key={c} code={c} size={32} />)}</div>
          <div><p className="text-sm font-semibold">{r.airlines.join(" + ")}</p><p className="text-xs text-slate-500">{r.legs.map((l) => l.flight_number).join(" · ")}</p></div>
        </div>
        <div className="flex items-center gap-2">
          {r.is_optimal && <span className="inline-flex items-center gap-1 rounded-full bg-blue-50 px-2.5 py-1 text-xs font-semibold text-blue-700"><Star size={12} fill="currentColor" /> Optimized route</span>}
          <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${r.stops === 0 ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-600"}`}>{r.route_type}</span>
        </div>
      </div>

      <div className="mt-5 grid items-center gap-4 sm:grid-cols-[1fr_2fr_1fr]">
        <div><p className="text-2xl font-bold">{fmtTime(r.departure)}</p><p className="text-sm text-slate-500">{first.from}</p></div>
        <div className="text-center">
          <p className="text-xs font-medium text-slate-500">{fmtDuration(r.total_duration_min)}</p>
          <div className="relative my-2 h-px bg-slate-300">{r.layovers.map((_, i) => <span key={i} className="absolute top-1/2 h-2.5 w-2.5 -translate-y-1/2 rounded-full border-2 border-slate-400 bg-white" style={{ left: `${((i + 1) / (r.layovers.length + 1)) * 100}%` }} />)}</div>
          <p className="text-xs text-slate-500">{r.stops === 0 ? "Non-stop" : `${r.stops} stop${r.stops > 1 ? "s" : ""} · ${r.layovers.map((l) => l.iata).join(", ")}`}</p>
        </div>
        <div className="sm:text-right"><p className="text-2xl font-bold">{fmtTime(r.arrival)}{off > 0 && <sup className="ml-1 text-xs text-red-500">+{off}</sup>}</p><p className="text-sm text-slate-500">{last.to}</p></div>
      </div>

      <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4">
        <div className="flex gap-5 text-sm text-slate-600"><span>{fmtKm(r.total_distance_km)}</span><span className="text-slate-300">|</span><span>{fmtPrice(r.price_per_passenger)} / person</span></div>
        <div className="flex items-center gap-3" onClick={(e) => e.stopPropagation()}>
          <div className="text-right"><p className="text-xl font-extrabold text-navy-900">{fmtPrice(r.total_price)}</p>{pax > 1 && <p className="text-[11px] text-slate-500">for {pax} passengers · est.</p>}</div>
          <button className="btn-ghost !p-2" title={saved ? "Remove saved route" : "Save route"} onClick={onToggleSave}>{saved ? <BookmarkCheck size={18} className="text-brand-600" /> : <Bookmark size={18} />}</button>
          <label className="flex cursor-pointer items-center gap-1.5 text-sm font-medium"><input type="checkbox" checked={compared} onChange={onToggleCompare} className="h-4 w-4 accent-blue-600" /> Compare</label>
          <button className="btn-ghost !p-2" aria-label="Show legs" onClick={() => setOpen(!open)}><ChevronDown size={18} className={open ? "rotate-180" : ""} /></button>
        </div>
      </div>

      {open && (
        <ol className="mt-4 space-y-2 rounded-xl bg-slate-50 p-3 text-sm" onClick={(e) => e.stopPropagation()}>
          {r.legs.map((l) => (
            <li key={l.flight_number} className="flex flex-wrap items-center justify-between gap-2">
              <span className="flex items-center gap-2"><AirlineLogo code={l.airline_code} size={22} /><b>{l.from} → {l.to}</b> <span className="text-slate-500">{l.flight_number}</span></span>
              <span className="text-slate-600">{fmtTime(l.departure)}–{fmtTime(l.arrival)} · {fmtDuration(l.duration_min)} · {fmtKm(l.distance_km)} · {fmtPrice(l.price)}</span>
            </li>
          ))}
        </ol>
      )}
    </article>
  );
}
