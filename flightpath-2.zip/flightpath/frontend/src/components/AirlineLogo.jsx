const COLORS = { AI: "#c8102e", "6E": "#2b3990", UK: "#5b2a86", EK: "#d71921", QR: "#5c0632", SQ: "#f99f1c", LH: "#05164d", BA: "#075aaa", TK: "#c8102e", EY: "#a68a52" };
export default function AirlineLogo({ code, size = 36 }) {
  return <span title={code} className="grid shrink-0 place-items-center rounded-full text-[11px] font-bold text-white" style={{ width: size, height: size, background: COLORS[code] || "#1a447f" }}>{code}</span>;
}
