export default function PageBand({ children, className = "" }) {
  return (
    <div className={`bg-hero relative ${className}`}>
      <div className="bg-grid absolute inset-0" />
      <div className="relative mx-auto max-w-7xl px-4 pb-10 pt-8 sm:px-6">{children}</div>
    </div>
  );
}
