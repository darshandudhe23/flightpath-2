import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeftRight, Search } from "lucide-react";
import AirportInput from "./AirportInput.jsx";
import { api } from "../services/api.js";
import { CLASSES, CRITERIA, tomorrow } from "../services/format.js";
import { useProfile } from "../hooks/useLocalStorage.js";

export default function SearchWidget({ initialTo, compact }) {
  const nav = useNavigate();
  const [profile] = useProfile();
  const [from, setFrom] = useState(null);
  const [to, setTo] = useState(null);
  const [date, setDate] = useState(tomorrow());
  const [pax, setPax] = useState(profile.passengers || 1);
  const [cls, setCls] = useState(profile.travel_class || "economy");
  const [by, setBy] = useState(profile.optimize_by || "price");
  const [error, setError] = useState("");

  useEffect(() => {
    if (profile.home) api.searchAirports(profile.home).then((r) => { const a = r.find((x) => x.iata === profile.home.toUpperCase()); if (a) setFrom((f) => f || a); }).catch(() => {});
  }, [profile.home]);
  useEffect(() => {
    if (initialTo) api.searchAirports(initialTo).then((r) => setTo(r.find((x) => x.iata === initialTo) || null)).catch(() => {});
  }, [initialTo]);

  const swap = () => { setFrom(to); setTo(from); };
  const submit = (e) => {
    e.preventDefault();
    if (!from || !to) return setError("Please choose both airports from the suggestions.");
    if (from.iata === to.iata) return setError("Origin and destination must be different airports.");
    if (!date) return setError("Please select a departure date.");
    setError("");
    nav(`/results?${new URLSearchParams({ from: from.iata, to: to.iata, date, pax, cls, by })}`);
  };

  return (
    <form onSubmit={submit} className={`card p-5 ${compact ? "" : "shadow-xl"}`}>
      <div className="grid items-end gap-3 lg:grid-cols-[1fr_auto_1fr]">
        <AirportInput label="From" placeholder="City or airport" value={from} onChange={setFrom} exclude={to?.iata} />
        <button type="button" onClick={swap} aria-label="Swap airports" className="btn-ghost mx-auto h-[42px] w-[42px] !p-0"><ArrowLeftRight size={16} /></button>
        <AirportInput label="To" placeholder="City or airport" value={to} onChange={setTo} exclude={from?.iata} />
      </div>
      <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <div><label className="label">Departure</label><input type="date" className="input" min={new Date().toISOString().slice(0, 10)} value={date} onChange={(e) => setDate(e.target.value)} /></div>
        <div><label className="label">Passengers</label><select className="input" value={pax} onChange={(e) => setPax(+e.target.value)}>{[1,2,3,4,5,6,7,8,9].map((n) => <option key={n} value={n}>{n} {n === 1 ? "passenger" : "passengers"}</option>)}</select></div>
        <div><label className="label">Class</label><select className="input" value={cls} onChange={(e) => setCls(e.target.value)}>{CLASSES.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}</select></div>
        <div><label className="label">Optimise for</label><select className="input" value={by} onChange={(e) => setBy(e.target.value)}>{CRITERIA.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}</select></div>
        <div className="flex items-end"><button className="btn-primary w-full !py-3"><Search size={16} /> Search Flights</button></div>
      </div>
      {error && <p role="alert" className="mt-3 text-sm font-medium text-red-600">{error}</p>}
    </form>
  );
}
