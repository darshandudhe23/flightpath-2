export function RouteCardSkeleton() {
  return (
    <div className="card space-y-4 p-5">
      <div className="flex justify-between"><div className="skeleton h-5 w-40" /><div className="skeleton h-5 w-24" /></div>
      <div className="skeleton h-12 w-full" />
      <div className="flex gap-3"><div className="skeleton h-4 w-24" /><div className="skeleton h-4 w-24" /></div>
    </div>
  );
}
export const ErrorBox = ({ message, onRetry }) => (
  <div className="card border-red-200 bg-red-50 p-6 text-center text-sm text-red-700">
    <p className="font-semibold">Something went wrong</p><p className="mt-1">{message}</p>
    {onRetry && <button className="btn-ghost mt-4" onClick={onRetry}>Try again</button>}
  </div>
);
