import { useState } from "react";
import { NavLink, Link, Outlet } from "react-router-dom";
import { Plane, Menu, X } from "lucide-react";

const links = [{ to: "/", label: "Search" }, { to: "/dashboard", label: "Dashboard" }];

export function Logo({ light }) {
  return (
    <Link to="/" className="flex items-center gap-2.5 text-lg font-extrabold tracking-tight">
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-navy-700 text-white shadow-md shadow-blue-500/30"><Plane size={18} className="-rotate-45" /></span>
      <span className={light ? "text-white" : "text-navy-900"}>Flight<span className="text-brand-500">Path</span></span>
    </Link>
  );
}

export default function MainLayout() {
  const [open, setOpen] = useState(false);
  const cls = ({ isActive }) => `rounded-full px-4 py-2 text-sm font-semibold transition ${isActive ? "bg-navy-900 text-white" : "text-slate-600 hover:bg-slate-100 hover:text-navy-900"}`;
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-[1000] border-b border-slate-200/70 bg-white/85 backdrop-blur-lg">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
          <Logo />
          <nav className="hidden gap-1 md:flex">{links.map((l) => <NavLink key={l.to} to={l.to} end className={cls}>{l.label}</NavLink>)}</nav>
          <button className="md:hidden" aria-label="Menu" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
        </div>
        {open && <nav className="flex flex-col gap-1 border-t border-slate-100 p-3 md:hidden">{links.map((l) => <NavLink key={l.to} to={l.to} end className={cls} onClick={() => setOpen(false)}>{l.label}</NavLink>)}</nav>}
      </header>
      <main className="flex-1"><Outlet /></main>
    </div>
  );
}
