export const fmtDuration = (m) => `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, "0")}m`;
export const fmtPrice = (n) => "₹" + Math.round(n).toLocaleString("en-IN");
export const fmtKm = (n) => Math.round(n).toLocaleString("en-IN") + " km";
export const fmtTime = (iso) => new Date(iso).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
export const dayOffset = (dep, arr) => Math.round((new Date(arr.slice(0, 10)) - new Date(dep.slice(0, 10))) / 864e5);
export const CRITERIA = [
  { value: "price", label: "Lowest price" },
  { value: "duration_min", label: "Shortest time" },
  { value: "distance_km", label: "Shortest distance" },
];
export const CLASSES = [
  { value: "economy", label: "Economy" }, { value: "premium", label: "Premium Economy" },
  { value: "business", label: "Business" }, { value: "first", label: "First" },
];
export const criterionLabel = (v) => CRITERIA.find((c) => c.value === v)?.label ?? v;
export const tomorrow = () => new Date(Date.now() + 864e5).toISOString().slice(0, 10);
