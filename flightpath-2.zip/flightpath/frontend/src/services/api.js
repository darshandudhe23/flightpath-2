const BASE = "/api";

async function request(path, { method = "GET", body } = {}) {
  let res;
  try {
    res = await fetch(BASE + path, { method, headers: body ? { "Content-Type": "application/json" } : undefined, body: body ? JSON.stringify(body) : undefined });
  } catch {
    throw new Error("Cannot reach the FlightPath server. Is the backend running on port 5000?");
  }
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

export const api = {
  airports: () => request("/airports"),
  searchAirports: (q) => request(`/airports/search?q=${encodeURIComponent(q)}`),
  searchFlights: (p) => request("/flights/search", { method: "POST", body: p }),
  compare: (p) => request("/routes/compare", { method: "POST", body: p }),
  details: (path, by) => request(`/routes/details?path=${path.join(",")}${by ? `&optimize_by=${by}` : ""}`),
  savedRoutes: () => request("/saved-routes"),
  saveRoute: (path, optimize_by) => request("/saved-routes", { method: "POST", body: { path, optimize_by } }),
  deleteSaved: (id) => request(`/saved-routes/${id}`, { method: "DELETE" }),
  history: () => request("/search-history"),
  clearHistory: () => request("/search-history", { method: "DELETE" }),
  favorites: () => request("/favorites"),
  addFavorite: (iata) => request("/favorites", { method: "POST", body: { iata } }),
  removeFavorite: (iata) => request(`/favorites/${iata}`, { method: "DELETE" }),
};
