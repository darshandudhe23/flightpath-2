import { Link, useSearchParams } from "react-router-dom";
import { Heart, ArrowUpRight, Plane } from "lucide-react";
import SearchWidget from "../components/SearchWidget.jsx";
import { useAsync } from "../hooks/useAsync.js";
import { api } from "../services/api.js";

const POPULAR = ["DXB", "SIN", "LHR", "JFK", "BKK", "SYD"];
const TONES = [
  "from-sky-500 to-blue-700", "from-indigo-500 to-blue-800", "from-slate-600 to-navy-900",
  "from-blue-500 to-indigo-800", "from-cyan-500 to-blue-700", "from-blue-600 to-navy-800",
];

export default function Landing() {
  const [params] = useSearchParams();
  const airports = useAsync(() => api.airports(), []);
  const favs = useAsync(() => api.favorites(), []);
  const favSet = new Set((favs.data || []).map((a) => a.iata));
  const popular = (airports.data || []).filter((a) => POPULAR.includes(a.iata)).sort((a, b) => POPULAR.indexOf(a.iata) - POPULAR.indexOf(b.iata));
  const toggleFav = async (a) => { favSet.has(a.iata) ? await api.removeFavorite(a.iata) : await api.addFavorite(a.iata); favs.reload(); };

  return (
    <>
      <section className="bg-hero relative overflow-hidden px-4 pb-36 pt-16 text-center text-white sm:px-6 sm:pt-24">
        <div className="bg-grid absolute inset-0" />
        <svg className="pointer-events-none absolute inset-x-0 bottom-10 mx-auto hidden w-full max-w-5xl opacity-40 md:block" viewBox="0 0 1000 160" fill="none" aria-hidden>
          <path d="M20 140 C 300 -40, 700 -40, 980 120" stroke="url(#g)" strokeWidth="2" strokeDasharray="6 8" />
          <circle cx="20" cy="140" r="6" fill="#93c5fd" /><circle cx="980" cy="120" r="6" fill="#67e8f9" />
          <defs><linearGradient id="g" x1="0" x2="1"><stop stopColor="#93c5fd" /><stop offset="1" stopColor="#67e8f9" /></linearGradient></defs>
        </svg>
        <div className="relative">
          <p className="mx-auto mb-5 flex w-fit items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-1.5 text-xs font-medium text-blue-100 backdrop-blur">
            <Plane size={13} className="-rotate-45" /> Intelligent flight route optimisation
          </p>
          <h1 className="mx-auto max-w-4xl text-4xl font-extrabold leading-tight tracking-tight sm:text-6xl">Find the <span className="text-gradient">Smartest Way</span> to Fly.</h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-blue-100/90">FlightPath models the airline network as a weighted graph and finds the cheapest, fastest or shortest connection between any two airports.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-2 text-xs font-medium text-blue-100">
            {["Lowest price", "Shortest time", "Shortest distance", "Smart alternatives"].map((t) => <span key={t} className="rounded-full border border-white/15 bg-white/5 px-3 py-1">{t}</span>)}
          </div>
        </div>
      </section>
      <div className="relative z-10 mx-auto -mt-28 max-w-5xl px-4 sm:px-6"><SearchWidget initialTo={params.get("to")} /></div>

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <div className="flex items-end justify-between">
          <div><p className="text-xs font-bold uppercase tracking-widest text-brand-600">Explore</p><h2 className="mt-1 text-3xl font-extrabold text-navy-900">Popular destinations</h2></div>
        </div>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {airports.loading ? Array.from({ length: 6 }, (_, i) => <div key={i} className="skeleton h-44" />) : popular.map((a, i) => (
            <div key={a.iata} className={`group relative overflow-hidden rounded-2xl bg-gradient-to-br ${TONES[i % TONES.length]} p-6 text-white shadow-lg shadow-blue-900/10 transition duration-300 hover:-translate-y-1 hover:shadow-xl`}>
              <span className="pointer-events-none absolute -bottom-6 -right-2 select-none text-8xl font-black tracking-tighter text-white/10">{a.iata}</span>
              <Link to={`/?to=${a.iata}`} onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} className="relative block h-full min-h-28">
                <span className="rounded-md bg-white/15 px-2 py-0.5 text-xs font-bold backdrop-blur">{a.iata}</span>
                <h3 className="mt-4 text-2xl font-bold">{a.city}</h3><p className="text-sm text-blue-100">{a.country}</p>
                <p className="mt-6 inline-flex items-center gap-1 text-sm font-semibold">Search flights <ArrowUpRight size={15} className="transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5" /></p>
              </Link>
              <button aria-label="Favorite" onClick={() => toggleFav(a)} className="absolute right-4 top-4 rounded-full bg-white/15 p-2 backdrop-blur transition hover:bg-white/25"><Heart size={16} className={favSet.has(a.iata) ? "fill-rose-400 text-rose-400" : "text-white"} /></button>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
