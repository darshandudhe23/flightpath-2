import { useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { GitCompare, SearchX } from "lucide-react";
import SearchWidget from "../components/SearchWidget.jsx";
import PageBand from "../components/PageBand.jsx";
import RouteCard from "../components/RouteCard.jsx";
import RouteMap from "../components/RouteMap.jsx";
import { RouteCardSkeleton, ErrorBox } from "../components/Skeleton.jsx";
import { useAsync } from "../hooks/useAsync.js";
import { pushRecentlyViewed } from "../hooks/useLocalStorage.js";
import { api } from "../services/api.js";
import { criterionLabel } from "../services/format.js";

const SORTS = { price: (r) => r.total_price, duration: (r) => r.total_duration_min, stops: (r) => r.stops, distance: (r) => r.total_distance_km };

export default function Results() {
  const [p] = useSearchParams();
  const nav = useNavigate();
  const q = { origin: p.get("from"), destination: p.get("to"), date: p.get("date"), passengers: +p.get("pax") || 1, travel_class: p.get("cls") || "economy", optimize_by: p.get("by") || "price" };
  const { data, error, loading, reload } = useAsync(() => api.searchFlights({ ...q, k: 8 }), [p.toString()]);
  const saved = useAsync(() => api.savedRoutes(), []);
  const [sort, setSort] = useState("best");
  const [airline, setAirline] = useState("");
  const [maxStops, setMaxStops] = useState("any");
  const [selected, setSelected] = useState(0);
  const [cmp, setCmp] = useState([]);
  const [msg, setMsg] = useState("");

  const routes = data?.routes || [];
  const airlines = useMemo(() => [...new Set(routes.flatMap((r) => r.airlines))].sort(), [routes]);
  const shown = useMemo(() => {
    let list = routes.filter((r) => (!airline || r.airlines.includes(airline)) && (maxStops === "any" || r.stops <= +maxStops));
    if (sort !== "best") list = [...list].sort((a, b) => SORTS[sort](a) - SORTS[sort](b));
    return list;
  }, [routes, airline, maxStops, sort]);
  const active = Math.min(selected, Math.max(shown.length - 1, 0));
  const savedMap = new Map((saved.data || []).map((s) => [s.path.join(), s.id]));

  const select = (i) => { setSelected(i); if (shown[i]) pushRecentlyViewed(shown[i].path); };
  const toggleCmp = (key) => setCmp((c) => (c.includes(key) ? c.filter((k) => k !== key) : c.length < 4 ? [...c, key] : c));
  const toggleSave = async (r) => {
    const key = r.path.join();
    try { savedMap.has(key) ? await api.deleteSaved(savedMap.get(key)) : await api.saveRoute(r.path, q.optimize_by); saved.reload(); }
    catch (e) { setMsg(e.message); setTimeout(() => setMsg(""), 3000); }
  };
  const goCompare = () => nav(`/compare?${new URLSearchParams({ paths: cmp.join(";"), by: q.optimize_by, pax: q.passengers, cls: q.travel_class, date: q.date || "" })}`);

  return (
    <>
    <PageBand><SearchWidget compact /></PageBand>
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">{q.origin} → {q.destination}</h1>
          <p className="text-sm text-slate-500">{loading ? "Finding best routes…" : `${shown.length} route${shown.length === 1 ? "" : "s"} · ranked by ${criterionLabel(q.optimize_by).toLowerCase()} · simulated sample data`}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <select aria-label="Sort" className="input !w-auto" value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="best">Recommended</option><option value="price">Lowest price</option><option value="duration">Shortest duration</option><option value="stops">Fewest stops</option><option value="distance">Shortest distance</option>
          </select>
          <select aria-label="Max stops" className="input !w-auto" value={maxStops} onChange={(e) => setMaxStops(e.target.value)}>
            <option value="any">Any stops</option><option value="0">Non-stop only</option><option value="1">Max 1 stop</option><option value="2">Max 2 stops</option>
          </select>
          <select aria-label="Airline" className="input !w-auto" value={airline} onChange={(e) => setAirline(e.target.value)}>
            <option value="">All airlines</option>{airlines.map((a) => <option key={a}>{a}</option>)}
          </select>
        </div>
      </div>
      {msg && <p className="mt-3 text-sm font-medium text-amber-700">{msg}</p>}

      {error ? <div className="mt-6"><ErrorBox message={error} onRetry={reload} /></div> : (
        <div className="mt-6 grid gap-6 lg:grid-cols-[1.1fr_1fr]">
          <div className="space-y-4">
            {loading && Array.from({ length: 3 }, (_, i) => <RouteCardSkeleton key={i} />)}
            {!loading && shown.length === 0 && (
              <div className="card p-10 text-center"><SearchX className="mx-auto text-slate-400" size={36} />
                <h2 className="mt-3 font-semibold">{routes.length ? "No routes match your filters" : "No routes found"}</h2>
                <p className="mt-1 text-sm text-slate-500">{routes.length ? "Try relaxing the stops or airline filter." : "These airports are not connected in the current dataset."}</p></div>
            )}
            {shown.map((r, i) => (
              <RouteCard key={r.path.join("-")} route={r} active={i === active} onSelect={() => select(i)} pax={q.passengers}
                compared={cmp.includes(r.path.join("-"))} onToggleCompare={() => toggleCmp(r.path.join("-"))}
                saved={savedMap.has(r.path.join())} onToggleSave={() => toggleSave(r)} />
            ))}
          </div>
          <aside className="lg:sticky lg:top-24 lg:self-start">
            {loading ? <div className="skeleton h-[480px]" /> : shown.length > 0 && <RouteMap routes={shown} selected={active} onSelect={select} height={480} />}
            {shown[active] && <p className="mt-2 text-xs text-slate-500">Showing <b>{shown[active].path.join(" → ")}</b>. Click a line or airport on the map for details.</p>}
          </aside>
        </div>
      )}

      {cmp.length > 0 && (
        <div className="fixed inset-x-0 bottom-4 z-[1100] mx-auto flex w-fit items-center gap-3 rounded-2xl bg-navy-900 px-5 py-3 text-sm text-white shadow-2xl">
          <span>{cmp.length} selected</span>
          <button className="btn-primary !py-1.5" disabled={cmp.length < 2} onClick={goCompare}><GitCompare size={15} /> Compare routes</button>
          <button className="text-blue-200 hover:text-white" onClick={() => setCmp([])}>Clear</button>
        </div>
      )}
    </div>
    </>
  );
}
