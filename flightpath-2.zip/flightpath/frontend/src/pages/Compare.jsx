import { useSearchParams } from "react-router-dom";
import { Trophy, ArrowLeft } from "lucide-react";
import RouteMap from "../components/RouteMap.jsx";
import { ErrorBox } from "../components/Skeleton.jsx";
import { useAsync } from "../hooks/useAsync.js";
import { api } from "../services/api.js";
import { criterionLabel, fmtDuration, fmtKm, fmtPrice } from "../services/format.js";

export default function Compare() {
  const [p] = useSearchParams();
  const paths = (p.get("paths") || "").split(";").filter(Boolean).map((s) => s.split("-"));
  const by = p.get("by") || "price";
  const { data, error, loading, reload } = useAsync(() => (paths.length >= 2 ? api.compare({ routes: paths, optimize_by: by, passengers: +p.get("pax") || 1, travel_class: p.get("cls") || "economy", date: p.get("date") || undefined }) : Promise.reject(new Error("Select at least two routes on the results page to compare."))), [p.toString()]);

  const rows = [
    { key: "price", label: "Estimated price", get: (r) => fmtPrice(r.total_price), best: "price" },
    { key: "time", label: "Travel time (incl. layovers)", get: (r) => fmtDuration(r.total_duration_min), best: "duration_min" },
    { key: "dist", label: "Total distance", get: (r) => fmtKm(r.total_distance_km), best: "distance_km" },
    { key: "stops", label: "Stops", get: (r) => r.stops, best: "stops" },
    { key: "conn", label: "Connecting airports", get: (r) => (r.layovers.length ? r.layovers.map((l) => l.iata).join(", ") : "None") },
    { key: "air", label: "Airlines", get: (r) => r.airlines.join(", ") },
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <button onClick={() => history.back()} className="inline-flex items-center gap-1 text-sm font-medium text-brand-600"><ArrowLeft size={14} /> Back to results</button>
      <h1 className="mt-3 text-2xl font-bold text-navy-900">Route comparison</h1>
      {error ? <div className="mt-6"><ErrorBox message={error} onRetry={reload} /></div> : loading ? <div className="skeleton mt-6 h-72" /> : (
        <>
          <p className="text-sm text-slate-500">Best match for <b>{criterionLabel(by).toLowerCase()}</b> is highlighted · simulated sample data</p>
          <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {data.routes.map((r, i) => (
              <div key={i} className={`card p-5 ${i === data.recommended_index ? "ring-2 ring-brand-500" : ""}`}>
                {i === data.recommended_index && <span className="mb-2 inline-flex items-center gap-1 rounded-full bg-blue-50 px-2.5 py-1 text-xs font-semibold text-blue-700"><Trophy size={12} /> Most suitable</span>}
                <p className="font-bold text-navy-900">{r.path.join(" → ")}</p>
                <p className="mt-2 text-2xl font-extrabold">{fmtPrice(r.total_price)}</p>
                <p className="text-sm text-slate-500">{fmtDuration(r.total_duration_min)} · {fmtKm(r.total_distance_km)}</p>
              </div>
            ))}
          </div>
          <div className="card mt-6 overflow-x-auto">
            <table className="w-full min-w-[640px] text-sm">
              <thead><tr className="border-b border-slate-100 text-left text-xs uppercase text-slate-500"><th className="p-4">Metric</th>{data.routes.map((r, i) => <th key={i} className="p-4">{r.path.join("-")}</th>)}</tr></thead>
              <tbody>{rows.map((row) => (
                <tr key={row.key} className="border-b border-slate-50 last:border-0">
                  <td className="p-4 font-medium text-slate-600">{row.label}</td>
                  {data.routes.map((r, i) => <td key={i} className={`p-4 ${row.best && data.best[row.best] === i ? "font-bold text-emerald-700" : ""}`}>{row.get(r)}{row.best && data.best[row.best] === i && " ✓"}</td>)}
                </tr>))}</tbody>
            </table>
          </div>
          <div className="mt-6"><RouteMap routes={data.routes} selected={data.recommended_index} height={420} /></div>
        </>
      )}
    </div>
  );
}
