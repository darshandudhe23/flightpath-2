import { Link, useNavigate } from "react-router-dom";
import { Bookmark, Clock, Eye, Heart, Settings, Trash2 } from "lucide-react";
import SearchWidget from "../components/SearchWidget.jsx";
import PageBand from "../components/PageBand.jsx";
import { useAsync } from "../hooks/useAsync.js";
import { PROFILE_DEFAULTS, useLocalStorage, useProfile } from "../hooks/useLocalStorage.js";
import { api } from "../services/api.js";
import { CLASSES, CRITERIA, criterionLabel, tomorrow } from "../services/format.js";
import { useState } from "react";

const Panel = ({ icon: I, title, action, children }) => (
  <section className="card p-5"><div className="mb-4 flex items-center justify-between"><h2 className="flex items-center gap-2 font-semibold text-navy-900"><I size={18} className="text-brand-600" /> {title}</h2>{action}</div>{children}</section>
);
const Empty = ({ children }) => <p className="rounded-xl bg-slate-50 p-4 text-center text-sm text-slate-500">{children}</p>;

export default function Dashboard() {
  const nav = useNavigate();
  const history = useAsync(() => api.history(), []);
  const saved = useAsync(() => api.savedRoutes(), []);
  const favs = useAsync(() => api.favorites(), []);
  const [recent] = useLocalStorage("fp_recent_routes", []);
  const [profile, setProfile] = useProfile();
  const [draft, setDraft] = useState(profile);
  const [ok, setOk] = useState(false);
  const routeLink = (path, by = "price") => `/results?${new URLSearchParams({ from: path[0], to: path.at(-1), date: tomorrow(), pax: profile.passengers, cls: profile.travel_class, by })}`;
  const upd = (k, v) => { setDraft({ ...draft, [k]: v }); setOk(false); };
  const submitProfile = (e) => { e.preventDefault(); setProfile({ ...draft, home: draft.home.trim().toUpperCase() }); setOk(true); };

  return (
    <>
    <PageBand>
      <h1 className="mb-5 text-2xl font-extrabold text-white sm:text-3xl">{profile.name ? `Welcome back, ${profile.name}` : "Your dashboard"}</h1>
      <SearchWidget compact />
      <div className="mt-5 grid grid-cols-3 gap-3 text-center text-white">
        {[["Saved routes", saved.data?.length], ["Favorites", favs.data?.length], ["Recent searches", history.data?.length]].map(([l, n]) => (
          <div key={l} className="rounded-xl border border-white/10 bg-white/10 py-3 backdrop-blur"><p className="text-2xl font-extrabold">{n ?? "–"}</p><p className="text-xs text-blue-100">{l}</p></div>))}
      </div>
    </PageBand>
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <div className="grid gap-6 lg:grid-cols-2">
        <Panel icon={Clock} title="Recent searches" action={history.data?.length > 0 && <button className="text-xs font-medium text-slate-500 hover:text-red-600" onClick={async () => { await api.clearHistory(); history.reload(); }}>Clear</button>}>
          {history.data?.length ? <ul className="divide-y divide-slate-100">{history.data.map((h) => (
            <li key={h.id}><Link className="flex justify-between py-2.5 text-sm hover:text-brand-600" to={`/results?${new URLSearchParams({ from: h.origin, to: h.destination, date: h.date || tomorrow(), pax: h.passengers, cls: h.travel_class, by: profile.optimize_by })}`}>
              <b>{h.origin} → {h.destination}</b><span className="text-slate-500">{h.date} · {h.passengers} pax</span></Link></li>))}</ul> : <Empty>No searches yet.</Empty>}
        </Panel>
        <Panel icon={Bookmark} title="Saved routes">
          {saved.data?.length ? <ul className="divide-y divide-slate-100">{saved.data.map((s) => (
            <li key={s.id} className="flex items-center justify-between py-2.5 text-sm"><Link className="hover:text-brand-600" to={routeLink(s.path, s.criterion)}><b>{s.path.join(" → ")}</b> <span className="text-slate-500">· {criterionLabel(s.criterion)}</span></Link>
              <button aria-label="Remove saved route" onClick={async () => { await api.deleteSaved(s.id); saved.reload(); }}><Trash2 size={16} className="text-slate-400 hover:text-red-600" /></button></li>))}</ul> : <Empty>Save a route from the results page using the bookmark icon.</Empty>}
        </Panel>
        <Panel icon={Heart} title="Favorite destinations">
          {favs.data?.length ? <div className="flex flex-wrap gap-2">{favs.data.map((a) => (
            <span key={a.iata} className="inline-flex items-center gap-2 rounded-full bg-brand-50 py-1.5 pl-3 pr-2 text-sm font-medium text-brand-600">
              <Link to={`/?to=${a.iata}`}>{a.city} ({a.iata})</Link><button aria-label={`Remove ${a.city}`} onClick={async () => { await api.removeFavorite(a.iata); favs.reload(); }}>×</button></span>))}</div> : <Empty>Tap the heart on a popular destination to add favorites.</Empty>}
        </Panel>
        <Panel icon={Eye} title="Recently viewed routes">
          {recent.length ? <ul className="divide-y divide-slate-100">{recent.map((p) => <li key={p.join()}><Link className="block py-2.5 text-sm font-semibold hover:text-brand-600" to={routeLink(p)}>{p.join(" → ")}</Link></li>)}</ul> : <Empty>Routes you click on in results appear here.</Empty>}
        </Panel>
      </div>
      <div className="mt-6"><Panel icon={Settings} title="Profile settings">
        <form onSubmit={submitProfile} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <div><label className="label">Name</label><input className="input" value={draft.name} onChange={(e) => upd("name", e.target.value)} /></div>
          <div><label className="label">Home airport (IATA)</label><input className="input" maxLength={3} placeholder="e.g. NDC" value={draft.home} onChange={(e) => upd("home", e.target.value)} /></div>
          <div><label className="label">Default optimisation</label><select className="input" value={draft.optimize_by} onChange={(e) => upd("optimize_by", e.target.value)}>{CRITERIA.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}</select></div>
          <div><label className="label">Default class</label><select className="input" value={draft.travel_class} onChange={(e) => upd("travel_class", e.target.value)}>{CLASSES.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}</select></div>
          <div className="flex items-end gap-2"><button className="btn-primary flex-1">Save</button><button type="button" className="btn-ghost" onClick={() => { setDraft(PROFILE_DEFAULTS); setProfile(PROFILE_DEFAULTS); }}>Reset</button></div>
        </form>{ok && <p className="mt-3 text-sm font-medium text-emerald-600">Settings saved on this device.</p>}
      </Panel></div>
    </div>
    </>
  );
}
