import { useState, useCallback } from "react";

export function useLocalStorage(key, initial) {
  const [value, setValue] = useState(() => {
    try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : initial; } catch { return initial; }
  });
  const set = useCallback((next) => {
    setValue((prev) => {
      const v = typeof next === "function" ? next(prev) : next;
      try { localStorage.setItem(key, JSON.stringify(v)); } catch { /* ignore */ }
      return v;
    });
  }, [key]);
  return [value, set];
}

export const PROFILE_DEFAULTS = { name: "", home: "", optimize_by: "price", travel_class: "economy", passengers: 1 };
export const useProfile = () => useLocalStorage("fp_profile", PROFILE_DEFAULTS);
export function pushRecentlyViewed(path) {
  try {
    const cur = JSON.parse(localStorage.getItem("fp_recent_routes") || "[]").filter((p) => p.join() !== path.join());
    localStorage.setItem("fp_recent_routes", JSON.stringify([path, ...cur].slice(0, 6)));
  } catch { /* ignore */ }
}
