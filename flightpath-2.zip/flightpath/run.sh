#!/usr/bin/env bash
# FlightPath one-command launcher (macOS / Linux).  Usage:  ./run.sh   (add --reset to reseed the database)
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"

command -v python3 >/dev/null || { echo "Python 3 not found. Install it from https://www.python.org/downloads/ (or: brew install python)"; exit 1; }
command -v npm >/dev/null || { echo "Node.js not found. Install it from https://nodejs.org (LTS) (or: brew install node)"; exit 1; }

echo "==> Backend setup"
cd "$ROOT/backend"
[ -d venv ] || python3 -m venv venv
source venv/bin/activate
pip install -q -r requirements.txt
[ "$1" = "--reset" ] && rm -f flightpath.db

echo "==> Frontend setup"
cd "$ROOT/frontend"
[ -d node_modules ] || npm install --no-audit --no-fund

cleanup() { echo; echo "Stopping FlightPath..."; kill $BACK_PID $FRONT_PID 2>/dev/null; exit 0; }
trap cleanup INT TERM

echo "==> Starting API on http://127.0.0.1:5000"
cd "$ROOT/backend" && python run.py > "$ROOT/backend.log" 2>&1 &
BACK_PID=$!

echo "==> Starting app on http://localhost:5173"
cd "$ROOT/frontend" && npm run dev -- --open &
FRONT_PID=$!

echo "FlightPath is running. Press Ctrl+C to stop. (API log: backend.log)"
wait
