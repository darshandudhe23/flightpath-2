"""Generates airports.csv and routes.csv. ALL flight data is SIMULATED sample data:
airport coordinates are real, but connections, flight numbers, durations and prices are estimates."""
import csv, math, os, random
HERE = os.path.dirname(os.path.abspath(__file__))
AIRPORTS = [
("DEL","Indira Gandhi International","Delhi","India",28.5562,77.1000),
("BOM","Chhatrapati Shivaji Maharaj International","Mumbai","India",19.0896,72.8656),
("BLR","Kempegowda International","Bengaluru","India",13.1986,77.7066),
("MAA","Chennai International","Chennai","India",12.9941,80.1709),
("CCU","Netaji Subhas Chandra Bose International","Kolkata","India",22.6547,88.4467),
("HYD","Rajiv Gandhi International","Hyderabad","India",17.2403,78.4294),
("PNQ","Pune International","Pune","India",18.5822,73.9197),
("NDC","Shri Guru Gobind Singh Ji Airport","Nanded","India",19.1833,77.3167),
("GOI","Manohar International","Goa","India",15.7443,73.8600),
("AMD","Sardar Vallabhbhai Patel International","Ahmedabad","India",23.0772,72.6347),
("COK","Cochin International","Kochi","India",10.1520,76.4019),
("JAI","Jaipur International","Jaipur","India",26.8242,75.8122),
("LKO","Chaudhary Charan Singh International","Lucknow","India",26.7606,80.8893),
("NAG","Dr. Babasaheb Ambedkar International","Nagpur","India",21.0922,79.0472),
("IXC","Chandigarh International","Chandigarh","India",30.6735,76.7885),
("DXB","Dubai International","Dubai","UAE",25.2532,55.3657),
("AUH","Zayed International","Abu Dhabi","UAE",24.4330,54.6511),
("DOH","Hamad International","Doha","Qatar",25.2731,51.6081),
("MCT","Muscat International","Muscat","Oman",23.5933,58.2844),
("SIN","Changi","Singapore","Singapore",1.3644,103.9915),
("KUL","Kuala Lumpur International","Kuala Lumpur","Malaysia",2.7456,101.7099),
("BKK","Suvarnabhumi","Bangkok","Thailand",13.6900,100.7501),
("HKG","Hong Kong International","Hong Kong","Hong Kong",22.3080,113.9185),
("NRT","Narita International","Tokyo","Japan",35.7720,140.3929),
("ICN","Incheon International","Seoul","South Korea",37.4602,126.4407),
("SYD","Kingsford Smith","Sydney","Australia",-33.9399,151.1753),
("CMB","Bandaranaike International","Colombo","Sri Lanka",7.1808,79.8841),
("KTM","Tribhuvan International","Kathmandu","Nepal",27.6966,85.3591),
("DAC","Hazrat Shahjalal International","Dhaka","Bangladesh",23.8433,90.3978),
("IST","Istanbul Airport","Istanbul","Turkey",41.2753,28.7519),
("LHR","Heathrow","London","United Kingdom",51.4700,-0.4543),
("CDG","Charles de Gaulle","Paris","France",49.0097,2.5479),
("FRA","Frankfurt Airport","Frankfurt","Germany",50.0379,8.5622),
("AMS","Schiphol","Amsterdam","Netherlands",52.3105,4.7683),
("ZRH","Zurich Airport","Zurich","Switzerland",47.4647,8.5492),
("JFK","John F. Kennedy International","New York","United States",40.6413,-73.7781),
("EWR","Newark Liberty International","Newark","United States",40.6895,-74.1745),
("SFO","San Francisco International","San Francisco","United States",37.6213,-122.3790),
("LAX","Los Angeles International","Los Angeles","United States",33.9416,-118.4085),
("YYZ","Toronto Pearson International","Toronto","Canada",43.6777,-79.6248),
("JNB","O. R. Tambo International","Johannesburg","South Africa",-26.1367,28.2411),
]
AIRLINES = [("AI","Air India"),("6E","IndiGo"),("UK","Vistara Sim"),("EK","Emirates"),("QR","Qatar Airways"),
 ("SQ","Singapore Airlines"),("LH","Lufthansa"),("BA","British Airways"),("TK","Turkish Airlines"),("EY","Etihad Airways")]
# undirected links: (a, b, [airline codes])
L=[]
dom_hubs=["DEL","BOM","BLR","MAA","CCU","HYD"]
for i,a in enumerate(dom_hubs):
    for b in dom_hubs[i+1:]: L.append((a,b,["AI","6E","UK"]))
for a,b in [("PNQ","DEL"),("PNQ","BLR"),("PNQ","BOM"),("PNQ","HYD"),("NDC","HYD"),("NDC","BOM"),("NDC","BLR"),("NAG","DEL"),("NAG","BOM"),("NAG","HYD"),
 ("GOI","BOM"),("GOI","BLR"),("GOI","DEL"),("GOI","HYD"),("AMD","DEL"),("AMD","BOM"),("AMD","BLR"),("COK","BLR"),("COK","MAA"),("COK","BOM"),("COK","DEL"),
 ("JAI","DEL"),("JAI","BOM"),("LKO","DEL"),("LKO","BOM"),("LKO","CCU"),("IXC","DEL"),("IXC","BOM")]: L.append((a,b,["AI","6E"]))
for a,b,al in [
 ("DEL","DXB",["AI","EK"]),("BOM","DXB",["AI","EK","6E"]),("BLR","DXB",["EK","6E"]),("HYD","DXB",["EK","6E"]),("COK","DXB",["EK","AI"]),("MAA","DXB",["EK","6E"]),
 ("DEL","DOH",["QR","AI"]),("BOM","DOH",["QR","6E"]),("HYD","DOH",["QR"]),("BLR","DOH",["QR"]),
 ("DEL","AUH",["EY","AI"]),("BOM","AUH",["EY","AI"]),("DXB","DOH",["EK","QR"]),("DXB","AUH",["EY"]),("MCT","DXB",["EK"]),("BOM","MCT",["6E","AI"]),("DEL","MCT",["AI"]),
 ("DEL","SIN",["SQ","AI"]),("BOM","SIN",["SQ","AI"]),("BLR","SIN",["SQ","6E"]),("MAA","SIN",["SQ","6E"]),("CCU","SIN",["SQ"]),("HYD","SIN",["SQ"]),
 ("DEL","BKK",["AI","6E"]),("CCU","BKK",["6E","AI"]),("MAA","BKK",["6E"]),("SIN","BKK",["SQ"]),("SIN","KUL",["SQ"]),("BKK","KUL",["6E"]),("BLR","KUL",["6E"]),("MAA","KUL",["6E"]),
 ("SIN","HKG",["SQ"]),("BKK","HKG",["SQ"]),("DEL","HKG",["AI"]),("HKG","NRT",["SQ"]),("SIN","NRT",["SQ"]),("HKG","ICN",["SQ"]),("NRT","ICN",["SQ"]),("DEL","NRT",["AI"]),("DEL","ICN",["AI"]),
 ("SIN","SYD",["SQ"]),("DEL","SYD",["AI"]),("KUL","SYD",["SQ"]),("BOM","SYD",["AI"]),
 ("CMB","MAA",["6E","UK"]),("CMB","BLR",["6E"]),("CMB","DEL",["AI"]),("CMB","SIN",["SQ"]),("CMB","DXB",["EK"]),
 ("KTM","DEL",["AI"]),("KTM","CCU",["AI"]),("KTM","DXB",["EK"]),("DAC","CCU",["AI","6E"]),("DAC","DEL",["AI"]),("DAC","DXB",["EK"]),("DAC","BKK",["TK"]),
 ("DEL","IST",["TK","AI"]),("BOM","IST",["TK"]),("DXB","IST",["TK","EK"]),("DOH","IST",["QR","TK"]),("IST","LHR",["TK","BA"]),("IST","FRA",["TK","LH"]),("IST","CDG",["TK"]),("IST","AMS",["TK"]),("IST","JFK",["TK"]),
 ("DEL","LHR",["AI","BA"]),("BOM","LHR",["AI","BA"]),("BLR","LHR",["BA"]),("DXB","LHR",["EK","BA"]),("DOH","LHR",["QR","BA"]),
 ("DEL","FRA",["LH","AI"]),("BOM","FRA",["LH"]),("BLR","FRA",["LH"]),("DXB","FRA",["EK","LH"]),("DOH","FRA",["QR","LH"]),
 ("DEL","CDG",["AI"]),("BOM","CDG",["AI"]),("DXB","CDG",["EK"]),("DOH","CDG",["QR"]),("DEL","AMS",["AI"]),("DXB","AMS",["EK"]),("DEL","ZRH",["AI"]),("BOM","ZRH",["LH"]),
 ("LHR","FRA",["BA","LH"]),("LHR","CDG",["BA"]),("LHR","AMS",["BA"]),("FRA","CDG",["LH"]),("FRA","AMS",["LH"]),("FRA","ZRH",["LH"]),("CDG","AMS",["LH"]),
 ("LHR","JFK",["BA"]),("LHR","EWR",["BA"]),("LHR","SFO",["BA"]),("LHR","LAX",["BA"]),("LHR","YYZ",["BA"]),("FRA","JFK",["LH"]),("FRA","SFO",["LH"]),("FRA","YYZ",["LH"]),("CDG","JFK",["LH"]),("AMS","JFK",["LH"]),("ZRH","JFK",["LH"]),
 ("DEL","JFK",["AI"]),("DEL","EWR",["AI"]),("BOM","EWR",["AI"]),("DEL","SFO",["AI"]),("BOM","SFO",["AI"]),("DEL","YYZ",["AI"]),("DXB","JFK",["EK"]),("DOH","JFK",["QR"]),("DXB","LAX",["EK"]),("DXB","SFO",["EK"]),("DOH","LAX",["QR"]),
 ("JFK","LAX",["BA"]),("JFK","SFO",["BA"]),("EWR","SFO",["BA"]),("EWR","LAX",["BA"]),("JFK","YYZ",["BA"]),("SFO","LAX",["BA"]),("SFO","YYZ",["BA"]),("JFK","EWR",["BA"]),
 ("NRT","SFO",["SQ"]),("NRT","LAX",["SQ"]),("HKG","SFO",["SQ"]),("SIN","SFO",["SQ"]),("ICN","LAX",["SQ"]),("SYD","LAX",["SQ"]),("SYD","SFO",["SQ"]),
 ("JNB","DXB",["EK"]),("JNB","DOH",["QR"]),("JNB","LHR",["BA"]),("JNB","FRA",["LH"]),("JNB","IST",["TK"]),("BOM","JNB",["AI"]),("DEL","JNB",["AI"]),
]: L.append((a,b,al))
def hav(a,b):
    la1,lo1,la2,lo2=map(math.radians,(a[4],a[5],b[4],b[5]))
    h=math.sin((la2-la1)/2)**2+math.cos(la1)*math.cos(la2)*math.sin((lo2-lo1)/2)**2
    return 6371*2*math.asin(math.sqrt(h))
if __name__=="__main__":
    ap={a[0]:a for a in AIRPORTS}
    rnd=random.Random(42)
    with open(os.path.join(HERE,"airports.csv"),"w",newline="",encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["iata","name","city","country","latitude","longitude"]); w.writerows(AIRPORTS)
    with open(os.path.join(HERE,"airlines.csv"),"w",newline="",encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["code","name"]); w.writerows(AIRLINES)
    seen=set(); rows=[]; num=100
    for a,b,airlines in L:
        if a not in ap or b not in ap or (min(a,b),max(a,b)) in seen: continue
        seen.add((min(a,b),max(a,b)))
        d=round(hav(ap[a],ap[b]))
        intl = ap[a][3]!=ap[b][3]
        for code in airlines:
            for o,t in ((a,b),(b,a)):
                num+=1
                dur=round(d/(780 if d>1500 else 680)*60+35)          # cruise time + taxi/climb allowance
                rate=(0.075 if intl else 0.062)*(1 if d>1500 else 1.15)  # USD-ish scale -> INR below
                price=round((1800+d*(6.2 if intl else 5.0))*rnd.uniform(0.88,1.18)/10)*10
                rows.append([f"{code}{num}",code,f"{code}{num}",o,t,d,dur,price])
    with open(os.path.join(HERE,"routes.csv"),"w",newline="",encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["flight_id","airline_code","flight_number","origin","destination","distance_km","duration_min","price_inr"]); w.writerows(rows)
    print(len(AIRPORTS),"airports,",len(rows),"flights")
