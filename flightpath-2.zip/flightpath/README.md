# FlightPath – Intelligent Flight Route Optimizer

Graph-theory based flight route finder (Data Structures & Algorithms course project).
Airports are vertices, flights are weighted directed edges (adjacency list). Routes are found with
**Dijkstra's algorithm (heapq min-heap)** and alternatives with **Yen's K-shortest paths**.
Distance, duration and price are each optimised separately – units are never mixed.

> **Data notice:** airport coordinates are real, but all flights, schedules, durations and prices are
> **simulated / estimated sample data** (see `datasets/generate_datasets.py`). Nothing is live availability.

## Structure
```
datasets/   airports.csv, airlines.csv, routes.csv, generate_datasets.py
backend/    Flask API: app/{routes,algorithms,models,services,database,utils}, run.py, tests/
frontend/   React + Vite + Tailwind v4 + Leaflet
```

## Quick start (macOS / Linux)
```bash
chmod +x run.sh run.command   # only if needed after unzipping
./run.sh                      # or double-click run.command in Finder
```
This creates the Python venv, installs dependencies, starts the API (port 5000) and the app (port 5173, opens in your browser). Press Ctrl+C to stop. Needs Python 3 (python.org/downloads) and Node.js LTS (nodejs.org); Homebrew is optional.

## Run manually
Requirements: Python 3.10+, Node 18+.

**Backend** (http://127.0.0.1:5000)
```bash
cd backend
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
python run.py            # creates flightpath.db and seeds it from ../datasets on first run
python run.py --reset    # optional: drop, recreate and reseed the database
```

**Frontend** (http://localhost:5173, proxies /api to the backend)
```bash
cd frontend
npm install
npm run dev
```

**Tests**
```bash
cd backend && python -m pytest -q
```

**Regenerate the dataset** (optional): `python datasets/generate_datasets.py`, then `python run.py --reset`.

## API
| Method | Endpoint | Purpose |
|---|---|---|
| GET | /api/airports, /api/airports/search?q= | list / autocomplete |
| POST | /api/flights/search | ranked route options (+ records search history) |
| POST | /api/routes/optimize | single optimal route (Dijkstra) |
| POST | /api/routes/alternatives | K distinct routes (Yen) |
| GET | /api/routes/details?path=DEL,DXB,JFK | details of a given path |
| POST | /api/routes/compare | compare 2–4 routes |
| GET/POST/DELETE | /api/saved-routes | saved routes |
| GET/DELETE | /api/search-history | recent searches |
| GET/POST/DELETE | /api/favorites | favorite destinations |

Body example: `{"origin":"NDC","destination":"JFK","optimize_by":"price|duration_min|distance_km","date":"2026-12-01","passengers":2,"travel_class":"economy","max_stops":2,"k":5}`

## Notes
* Total duration includes a fixed 90‑minute layover per connection; the departure time of the first leg is a fixed simulated 08:00.
* Profile settings and "recently viewed" are stored in the browser (localStorage); everything else is in SQLite.
* No algorithm visualisation/demo module is included, by design.
