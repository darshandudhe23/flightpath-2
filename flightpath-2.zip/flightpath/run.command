#!/usr/bin/env bash
# Double-click this file in Finder to launch FlightPath on macOS.
cd "$(dirname "$0")" && ./run.sh
